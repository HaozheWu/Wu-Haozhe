public class Dictionary implements Map<String, Integer> {

    private final static int INITIAL_CAPACITY = 10;
    private final static int INCREMENT = 5;
    private int count;

    private Pair[] elems;
  

    public int getCount() {
      return count;
    }

    public int getCapacity() {
      return elems.length;
    }

    public Dictionary() {
        /* Your code here */
    elems= new Pair[INITIAL_CAPACITY];
    }

    @Override
    public void put(String key, Integer value) {
    	if (count==elems.length){
    		this.increaseCapacity();
    	}
        /* Your code here */
    	Pair a=new Pair(key,value);
    	elems[count]=a;
    	count++;
    }

	private void increaseCapacity() {
        /* Your code here.  Use this in put() where necessary. */
    if (count>=INITIAL_CAPACITY) {
    	Pair[] result = new Pair[count+INCREMENT];
    	for(int i=0;i<count;i++) {
    		result[i]=elems[i];
    	}
    	elems=result;
    	}
    }
    @Override
    public boolean contains(String key) {
    	if(count==0) {
    		return false;
    	}
        for (int j=count-1;j>=0;j--){
        	if (key.equals(elems[j].getKey())){
        		return true;
        	}
        }
        return false;
    }

    @Override
    public Integer get(String key) {
 
    for (int j=count-1;j>=0;j--){
    	if (key.equals(elems[j].getKey())){
        	return elems[j].getValue();
        	}
        }
	return null;
     	

    }

    @Override
    public void replace(String key, Integer value) {
        /* Your code here. */
    	for (int j=count-1;j>=0;j--){
    		if (key.equals(elems[j].getKey())){
        		elems[j]=new Pair(key,value);
        	}
    	}
    	
    	
    }

    @Override
    public Integer remove(String key) {
    	Integer a= null;
        for(int j=count-1;j>=0;j--) {
        	if (key.equals(elems[j].getKey())){
        		a=elems[j].getValue();
        		elems[j]=new Pair(null,null);
                count--;
        		break;
        	}
        }
        return a;
    }

    @Override
    public String toString() {
      String res;
      res = "Dictionary: {elems = [";
      for (int i = count-1; i >= 0 ; i--) {
          res += elems[i];
          if(i > 0) {
              res += ", ";
          }
      }
      return res +"]}";
    }

}