student_1: shifeng song 300018700 A03
student_2: Haozhe Wu 300010064   A01
This assignment contains two parts :
 part1:A1Q1.java A1Q1Test.javan A1Q2.java A1Q2Test.java
A1Q3.java A1Q3Test.java StudentInfo.java Utils.java

part2:Card.java Deck.java Die.java Game.java Run.java StudentInfo.java Utils.java Test.java
and README.txt