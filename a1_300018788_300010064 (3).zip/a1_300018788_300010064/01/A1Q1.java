public class A1Q1{ 
	public static int countPositive(double[] Number){
		int result =0;
		for (int i=0;i<Number.length;i++){
			if(Number[i]>0){
				result=result+1;
		}
	}

	return result;
}
}