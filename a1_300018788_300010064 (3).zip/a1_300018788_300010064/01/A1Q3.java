public class A1Q3 {
	public static int getLongestRun(double[] a){
		int result,record;
		result=1;
		record=1;
		if (a.length<2){
			return (a.length);
		}
		else{
			for (int i=0;i<a.length-1;i++){
				while(a[i]==a[i+1]){
					result=result+1;
					i=i+1;
					}
					if (record>result){
						result=1;
					}
					else {
						record=result;
						result=1;
							}
				}
			}
			return record;

		}
		public static int getLongestRun(String[] a){
			int result,record;
			result=1;
			record=1;
			for (int i=0;i<a.length-1;i++){
				while((a[i]).equals(a[i+1])){
					result=result+1;
					i=i+1;
					}
					if (record>result){
						result=1;
					}
					else {
						record=result;
						result=1;
							}
				}
			
			return record;
		}
}