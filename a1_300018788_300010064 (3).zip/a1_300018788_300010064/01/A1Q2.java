public class A1Q2{
	public static boolean hasLengthTwoRun(double[] a){
		boolean result =false;
		if (a.length<2){
			return false;
		}
		else{
			for (int i=0;i<a.length-1;i++){
					if(a[i]==a[i+1]){
						result=true;
					}
				}
			}
		
		return result;
}
}