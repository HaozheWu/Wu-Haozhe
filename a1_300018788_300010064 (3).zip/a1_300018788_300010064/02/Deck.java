/**
* Starting point for your implementation of the class Deck.
*
* @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
*/

import java.util.ArrayList;
import java.util.Collections;

public class Deck {

    private ArrayList<Card> cards;

    /**
    * A constructor for the class <code>Deck</code>. It creates the initial
    * <code>ArrayList</code> that will be used to store the cards of Otherwise
    * deck.
    */

    public Deck() {
        cards = new ArrayList<Card>();
    }

    /**
    * A constructor for the class <code>Deck</code>. It creates the initial
    * <code>ArrayList</code> that will be used to store the cards of Otherwise
    * deck. The parameter specifies the number of ranks for the cards. Finally,
    * it also initializes this deck to contain 4 x n cards, where n is the value
    * of the parameter.
    *
    * @param range the number of ranks for the cards
    */


    public Deck(int range) {

        // Complete the implementation of this constructor
        cards = new ArrayList<Card>();
        for(int i = 1;i<= range;i++){
            cards.add(new Card(Card.DIAMOND, i ));
            cards.add(new Card(Card.CLUB, i ));
            cards.add(new Card(Card.HEART, i ));
            cards.add(new Card(Card.SPADE, i ));
        }

    }
    int size(){
        return cards.size();
    }

    boolean hasCards(){
        return cards.size() >=1;
    }

    Card get(int pos){
        return cards.get(pos-1);
    }

    void add(Card card){
        cards.add(card);
    }

    void addAll(Deck other){
        cards.addAll(cards.size(),other.cards);
        other.cards.clear();
    }

    Card removeLast(){
        Card newCard;
        newCard = cards.get(cards.size()-1);
        cards.remove(cards.size()-1);
        return newCard;
    }
    Card removeFirst(){
        Card firstCard;
        firstCard = cards.get(0);
        cards.remove(0);
        return firstCard;
    }
    boolean remove(Card card){
        return cards.remove(card);
    }

    void removeAll(Deck other){
        cards.removeAll(other.cards);
    }

    void shuffle(){
        Collections.shuffle(cards);
    }

    Deck deal(int n){
        Deck newDeck;
        newDeck = new Deck();
        for(int i = 0;i <n;i++){
            newDeck.cards.add(this.cards.get(this.cards.size()-1));
            this.cards.remove(this.cards.size()-1);
        }
        return newDeck;
    }

    boolean contains(Card card){
        return this.cards.contains(card);
    }

    boolean containsAll(Deck other){
        for(int i = 0; i< other.cards.size()-1;i ++ ){
           if(!this.cards.contains(other.cards.get(i))){
                return false;
           } 
        }
        return true;
    }

    boolean isKind(){
        sortBySuit();
        if (this.cards.size() <2){
            return false;
        }
        for(int i = 0; i < this.cards.size()-1;i++){
            for(int j = i+1; j< this.cards.size();j++){
                if(this.cards.get(i).getRank() != this.cards.get(j).getRank()){
                    return false;
                }
            }
        }
        return true;
    }

    boolean isSeq(){
        sortBySuit();
        if(this.cards.size()<3){
            return false;
        }
        for(int i = 0; i < this.cards.size() - 1; i++){
            for(int j = i + 1; j < this.cards.size();j++){
                int sum;
                sum = cards.get(i+1).getRank() - 1;
                if(this.cards.get(i).getSuit() != this.cards.get(j).getSuit()|| this.cards.get(i).getRank() != sum){
                    return false;
                }
            }
        }
        return true;
    }

    void sortBySuit(){
        for(int i = 0;i <this.cards.size()-1;i++){
            Card copy1;
            Card copy2;
            for(int j = i +1;j <this.cards.size();j++){
                if(this.cards.get(i).getSuit()*100 + this.cards.get(i).getRank() > this.cards.get(j).getSuit()*100 + this.cards.get(j).getRank() ){
                    copy1 = this.cards.get(i);
                    copy2 = this.cards.get(j);
                    this.cards.set(i,copy2);
                    this.cards.set(j,copy1);
                }
            }
        }
    }

    void sortByRank(){
        for(int i = 0;i <this.cards.size()-1;i++){
            Card copy1;
            Card copy2;
            for(int j = i +1;j <this.cards.size();j++){
                if(this.cards.get(i).getRank()*100 + this.cards.get(i).getSuit() > this.cards.get(j).getRank()*100 + this.cards.get(j).getSuit() ){
                    copy1 = this.cards.get(i);
                    copy2 = this.cards.get(j);
                    this.cards.set(i,copy2);
                    this.cards.set(j,copy1);
                }
            }
        }
    }

    void print(){
        System.out.println("Printed by suit");
        sortBySuit();
        for(int i = 0; i<cards.size();i++){
            System.out.print(this.cards.get(i).toString());
        

        }
        sortByRank();
        for(int i = 0; i<cards.size();i++){
            System.out.print(this.cards.get(i).toString());
        }
    }

    public String toString(){
        String myString;
        myString = "";
        for(int i = 0; i < this.cards.size();i++){
            myString +=( "{"+ this.cards.get(i).getSuit() + "," + this.cards.get(i).getRank() + "}");
        }
        return myString;
    }
}