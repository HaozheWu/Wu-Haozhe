import java.util.Random;
public class Die{
	int die;
	public Die(){
		Random a = new Random();
		die = a.nextInt(6) +1;
	}
	int getValue(){
		return die;
	}
	public void roll(){
		Random newa = new Random();
		this.die = newa.nextInt(6) + 1;
	} 
	public String toString(){
		String toString ="Die  "+"{value:"+die+"}";
		return toString;
	}
	public final int MAXVALUE = 6;
	
}