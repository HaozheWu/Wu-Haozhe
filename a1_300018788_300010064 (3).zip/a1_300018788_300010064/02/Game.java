import java.util.Scanner;
public class Game{
	Card crd ;
	int round = 0;
	Deck mainDeck;
	Deck handDeck;
	Die aDie;
	public Game(int numRank){
		mainDeck = new Deck(numRank);
		aDie = new Die();
	}
	public void play(){
		handDeck = new Deck();
		mainDeck.shuffle();
		handDeck.addAll(mainDeck.deal(7));
		System.out.println("Here is your  cards printed in two ways.");
		handDeck.sortBySuit();
		System.out.println(handDeck.toString());
		handDeck.sortByRank();
		System.out.println(handDeck.toString());

		while(handDeck.size()!= 0 && mainDeck.size() != 0){
			aDie.roll();
			
			System.out.println("Rolling a die. you got "+ aDie.getValue());
			if(aDie.getValue() == 1){
				System.out.println("round "+ (round + 1) + " starts.");
				boolean check;
				check = true;
				System.out.println("You got 1,you can decard any card you like.");
				System.out.println("Here is your  cards printed in two ways.");
				handDeck.sortBySuit();
				System.out.println(handDeck.toString());
				handDeck.sortByRank();
				System.out.println(handDeck.toString());
				while(check){
					System.out.println(" Which card would you like to descard?");
					crd = Utils.readCard();
					if(handDeck.contains(crd)){
						check = false;
					}else{
						System.out.println("card not in your hand.try again.");
					}
				}

				handDeck.remove(crd);
				System.out.println("Here is your  cards printed in two ways.");
				handDeck.sortBySuit();
				System.out.println(handDeck.toString());
				handDeck.sortByRank();
				System.out.println(handDeck.toString());
				round += 1;
				System.out.println("round "+ round + " completed.");
			}
			else{
				boolean discard;
				if(aDie.getValue() > mainDeck.size()){
					System.out.println("round "+ (round + 1) + " starts.");
					System.out.println("Since your rolled,"+ aDie.getValue()+",the Deck only has  "+ mainDeck.size()+" cards." + mainDeck.size()+" cards will be added to your hands.");
					handDeck.addAll(mainDeck);
					System.out.println("The deck is empty. and Here is your  cards printed in two ways.");
					handDeck.sortBySuit();
					System.out.println(handDeck.toString());
					handDeck.sortByRank();
					System.out.println(handDeck.toString());
					boolean ask;
					ask = true;
					Deck check1;
					boolean check2;
					while(ask){
						if(handDeck.size()!=0){
							discard = Utils.readYesOrNo("Yes or no, do you  have a sequences of three or more cards of the same suit or two or more of a kind? ");
							if(!discard){
								ask = false;
							}
							else if(ask){
							check1 = Utils.readCards("Enter cards you want to descard.");

							while(!handDeck.containsAll(check1)){
								System.out.println("card not in your hand. try angain.");
								check1 = Utils.readCards("Enter cards you want to descard.");
							}

							if(check1.isKind()||check1.isSeq()){
								handDeck.removeAll(check1);
							}
							else{
								System.out.println("Your cards are not a melds.tryagain.");
							}

							}
							System.out.println("Here is your  cards printed in two ways.");
							handDeck.sortBySuit();
							System.out.println(handDeck.toString());
							handDeck.sortByRank();
							System.out.println(handDeck.toString());
						}
						else if(handDeck.size() == 0){
							ask = false;

						}						
					}
					
					round += 1;
					System.out.println("round "+ round + " completed.");

				}
				else{
					System.out.println("Since your rolled,"+ aDie.getValue()+" the following "+ aDie.getValue()+" cards will be added to your hand from deck.");
					handDeck.addAll(mainDeck.deal(aDie.getValue()));
					
					boolean ask1;
					ask1 = true;
					
					Deck check3;
					boolean check4;
					boolean discard1;
					while(ask1){
						if(handDeck.size()!=0){
							System.out.println("Here is your  cards printed in two ways.");
							handDeck.sortBySuit();
							System.out.println(handDeck.toString());
							handDeck.sortByRank();
							System.out.println(handDeck.toString());
							discard1 = Utils.readYesOrNo("Yes or no, do you  have a sequences of three or more cards of the same suit or two or more of a kind? ");

							if(!discard1){
								ask1 = false;
							}
							else if(ask1){
							check3 = Utils.readCards("Enter cards you want to descard.");

							while(!handDeck.containsAll(check3)){
								System.out.println("card not in your hand. try angain.");
								check3 = Utils.readCards("Enter cards you want to descard.");
							}
							
							if(check3.isKind()||check3.isSeq()){
								handDeck.removeAll(check3);
							}
							else{
								System.out.println("Your cards are not a melds.tryagain.");
							}								
							}

						}else if(handDeck.size() == 0){
							ask1 = false;
						}	
											
					}
					
					round += 1;
					System.out.println("round "+ round + " completed.");

				}
			}
		}
		while(handDeck.size()!= 0 && mainDeck.size() == 0){
			System.out.println("round "+ (round + 1) + " starts.");
			System.out.println("The game is in empty deck phase.");
			
			System.out.println("Here is your  cards printed in two ways.");
			handDeck.sortBySuit();
			System.out.println(handDeck.toString());
			handDeck.sortByRank();
			System.out.println(handDeck.toString());
			boolean check = true;
			while(check){
				System.out.println(" Which card would you like to descard?");
				crd = Utils.readCard();
				while(!handDeck.contains(crd)){
					System.out.println("card not in your hand.try again.");
					crd = Utils.readCard();
				}
				check = false;

			}

			handDeck.remove(crd);
			if(handDeck.size() == 0){
				break;
			}
			round += 1;
			System.out.println("round "+ round + " completed.");
		}
			

		System.out.println("Congratulations, you completed the game in " + round + "rounds.");

	}
}