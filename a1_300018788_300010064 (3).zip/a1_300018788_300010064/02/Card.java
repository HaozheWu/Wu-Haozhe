
public class Card{
	int suit,rank;

	Card(int suit,int rank){
		this.suit = suit;
		this.rank = rank;
	}

	int getSuit(){
		return suit;
	}

	int getRank(){
		return rank;
	}

	public boolean equals(Object object){
		if(!(object instanceof Card)){
			return false;
		}

		Card other;
		other = (Card) object;

		return this.suit == other.suit && this.rank == other.rank;
	}

	public String toString(){
		String toString;
		toString = "{"+suit+","+rank+"}";
		return toString;
	}
	
	public static final int DIAMOND = 0;
	public static final int CLUB = 1;
	public static final int HEART = 2;
	public static final int SPADE = 3;

	
}