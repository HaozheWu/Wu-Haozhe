import java.util.NoSuchElementException;

public class Iterative {

    public static BitList complement( BitList in ) {
    	BitList out = new BitList();
    	while(in.getfirst()!=null) {
    	int a=in.removeFirst();
    	int b=1-a;
        out.addFirst( b );
    	}
    	while(out.getfirst()!=null) {
    		int a=out.removeFirst();
    		in.addFirst( a );
    	}
    	return in;
    	}
    	

    public static BitList or( BitList a, BitList b ) {
    	if(a.getlength()==0||b.getlength()==0||a.getlength()!=b.getlength()) {
    		throw new IllegalArgumentException();
    	}
    	BitList out = new BitList();
    	BitList in= new BitList();
    	while(a.getfirst()!=null||b.getfirst()!=null) {
    	int c=a.removeFirst();
        int d=b.removeFirst();
        if(c==1||d==1) {
        	out.addFirst(1);
        }
        else {
        	out.addFirst(0);
        }
    	}
        while(out.getfirst()!=null) {
    		int a1=out.removeFirst();
    		in.addFirst( a1 );
    	}
    	return in;
    	
    	
    
    }

	  public static BitList and( BitList a, BitList b ) {
		  if(a.getlength()==0||b.getlength()==0||a.getlength()!=b.getlength()) {
	    		throw new IllegalArgumentException();
	    	}

    	BitList out = new BitList();
    	BitList in= new BitList();
    	while(a.getfirst()!=null||b.getfirst()!=null) {
    	int c=a.removeFirst();
        int d=b.removeFirst();
        if(c==1&&d==1) {
	    	out.addFirst(1);
	    }
	    else {
	    	out.addFirst(0);
	    }
		}
	    while(out.getfirst()!=null) {
			int a1=out.removeFirst();
			in.addFirst( a1 );
		}
		return in;
	
}

	  public static BitList xor( BitList a, BitList b ) {
		  if(a.getlength()==0||b.getlength()==0||a.getlength()!=b.getlength()) {
	    		throw new IllegalArgumentException();
	    	}

		  BitList out = new BitList();
	    	BitList in= new BitList();
	    	while(a.getfirst()!=null||b.getfirst()!=null) {
	    	int c=a.removeFirst();
	        int d=b.removeFirst();
	        if(c!=d) {
		    	out.addFirst(1);
		    }
		    else {
		    	out.addFirst(0);
		    }
			}
		    while(out.getfirst()!=null) {
				int a1=out.removeFirst();
				in.addFirst( a1 );
			}
			return in;
			}
}