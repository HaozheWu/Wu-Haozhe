public interface View {
	void update () ;
}