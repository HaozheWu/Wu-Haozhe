import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GraphicalView extends JFrame implements View {
	private static final long serialVersionUID = 1L;
	private JLabel input;
	private Timer model;
	public GraphicalView (Timer model, Controller controller) {
		setLayout (new GridLayout(2, 3));
		this.model = model;
		JButton button,button2,button3,button4,button5,button6;
		button = new JButton("IncrementHours");
		button.addActionListener(controller);
		

		button2 = new JButton ( "IncrementMinutes" );
		button2.addActionListener ( controller );
		button2.setVerticalTextPosition(JButton.BOTTOM);
		button2.setHorizontalTextPosition(JButton.LEFT);
		button2.setLocation(4, 0);
		
		
		button3 = new JButton ( "IncrementSeconds" );
		button3.addActionListener ( controller );
		button3.setVerticalTextPosition(JButton.CENTER);
		button3.setHorizontalTextPosition(JButton.RIGHT);
		
		button4 = new JButton ( "DecrementHours" );
		button4.addActionListener ( controller );
		button4.setVerticalTextPosition(JButton.BOTTOM);
		button4.setHorizontalTextPosition(JButton.RIGHT);
		add(button4);
		button5 = new JButton ( "DecrementMinutes" );
		button5.addActionListener ( controller );
		
		button6 = new JButton ( "DecrementSeconds" );
		button6.addActionListener ( controller );
		
		input = new JLabel ();
	
		add(button);
		add(button2);
		add(button3);
		add(input);
		add(button4);
		add(button5);
		add(button6);
		
		// Your code here.

		//setup
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(700, 100);

		//display the window
		setVisible(true);
	}
	public void update () {
	input.setText(model.toString());
}
}