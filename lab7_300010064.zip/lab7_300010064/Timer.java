public class Timer {
	private int hours;
	private int minutes;
	private int seconds;

	public Timer(){
		hours = 0;
		minutes = 0;
		seconds = 0;
	}

	public void incrementHours(){
		if(this.hours==23) {
			hours=0;
		}
		else {
		this.hours=(hours+1);
		}
	}
	public void decrementHours(){
		if(this.hours>=0) {
		this.hours=((hours-1)%24);
		}
		if(this.hours<0) {
			this.hours=24+this.hours;
		}
	}

	public int getHours(){
		return hours;
	}

	public void incrementMinutes(){
		if(this.minutes==59) {
		this.minutes=0;
		incrementHours();
		}
		else {
		minutes++;
		}
	}
	public void decrementMinutes(){
		if(this.minutes>=0) {
			this.minutes=((minutes-1)%60);
			}
			if(this.minutes<0) {
				this.minutes=60+this.minutes;
				decrementHours();
			}
	}

	public int getMinutes() {
		return minutes;
	}

	public void incrementSeconds(){
		if(this.seconds==59) {
			this.seconds=0;
			incrementMinutes();
		}
		else {
			seconds++;
		}
	}

	public void decrementSeconds(){
		if(this.seconds>=0) {
			this.seconds=((seconds-1));
			}
			if(this.seconds<0) {
				this.seconds=60+this.seconds;
				decrementMinutes();
			}
	
	}
	
	public int getSeconds(){
		return seconds;
	}

	public String toString () {
		return "Timer "+hours+":"+minutes+":"+seconds;
	}
}