public class Book {

    private String author;
    private String title;
    private int year;

    public Book (String author, String title, int year) {
        this.author=author;
        this.title=title;
        this.year=year;
    }

    public String getAuthor() {
        return this.author;
    }

    public String getTitle() {
        return this.title;
        }

    public int getYear() {
        return this.year;
    }

    public boolean equals(Object other) {
    	if((this==null||other==null)){
    		return false;
    	}
    	if (this.getClass()!=other.getClass()) {
    		return false;
    	}

    	Book a=(Book)other;
    	if(this.author==null||a.author==null) {
    		return this.author==null&&a.author==null;
    	}
    	
    	if(this.title==null||a.title==null) {
    		return this.title==null&&a.title==null;
    	}
    	
    	return this.author.equals(a.author)&&this.year==(a.year)&&this.title.equals(a.title);

    	
       
    }

    private boolean istanceof(Object other) {
		// TODO Auto-generated method stub
		return false;
	}

	public String toString() {
        String result;
        result =this.author+": "+this.title+" ("+this.year+")";
        return result;   
    }
}
