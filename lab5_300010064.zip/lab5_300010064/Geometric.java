public class Geometric extends AbstractSeries {
	double sum = 0.0;
	int position=-1;

		
	public double next() {
		position++;
		sum = 1/Math.pow(2, position)+sum;
    	return sum;
    	
    	
    }
}
    
