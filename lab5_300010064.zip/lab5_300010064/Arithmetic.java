public class Arithmetic extends AbstractSeries {
	int position=0;
	int sum=0;
	public double next() {
		position++;
		sum=sum+position;
    	return  sum;
    	
    }
    

	

	
      
}