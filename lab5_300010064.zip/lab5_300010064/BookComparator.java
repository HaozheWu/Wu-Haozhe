import java.util.Comparator;

public class BookComparator implements Comparator<Book> {
	 public int Compare(String a,String b) {
		 return a.compareTo(b);
		 }
	 public int Compare(int a,int b) {
		  if(a<b) {
			  return -1;
		  }
		  else if(a==b) {
			  return 0;
		  }
		  return 1;
	 }
	 public int compare(Book a,Book b) {
	 if (Compare(a.getAuthor(),b.getAuthor())==0){
		 if (Compare(a.getTitle(),b.getTitle())==0) {
			 return Compare(a.getYear(),b.getYear());
		 }
		 return Compare(a.getTitle(),b.getTitle());
	 }
	 return Compare(a.getAuthor(),b.getAuthor());
	
	}
}