Student name: Haozhe Wu
Student number: 300010064
Course code: ITI1121
Lab section: A-01

This archive contains the 6 files of lab 4, that is, this file (README.txt),
plus the files Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.