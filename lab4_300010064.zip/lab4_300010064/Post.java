
import java.util.Calendar;
import java.util.Date;

public class Post implements Likeable, Comparable<Post> {

    protected int likes;
    protected Date timeStamp;
    protected String userName;

    public Post(String userName) {
      this.userName=userName;
      timeStamp = Calendar.getInstance().getTime();
      likes = 0;
    }
    

    public String getUserName() {
	     return userName;
    }

    public Date getTimeStamp() {
	     return timeStamp;
    }
    public void like() {
       this.likes =likes+1;
      
   }
   public int getLikes() {
       // TODO Auto-generated method stub
       return this.likes;
   }

    // Implement the methods required by the interface Likeable.
    // This file will not compile unless they are present with the correct name and signature.

    public String toString() {
    	String str = new String();
    	str = getClass().getName() + ": " + timeStamp + ", " + userName + ", likes = " + likes;
    	return  str;
    }


  	public int compareTo(Post other){
      return this.getTimeStamp().compareTo(other.getTimeStamp());
  	}

  	public boolean isPopular(){
  		if(getLikes()>100){
           return true;
       }
       return false;
  	}

}
