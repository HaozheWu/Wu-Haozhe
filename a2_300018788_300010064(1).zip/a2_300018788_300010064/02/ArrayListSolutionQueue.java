import java.util.ArrayList;
public class ArrayListSolutionQueue implements SolutionQueue{
	public ArrayList<Solution> queue;
	public ArrayListSolutionQueue(){
		queue=new ArrayList<Solution>();
	}
	public void enqueue( Solution s ){
		queue.add(s);
	}
	public Solution dequeue(){
		Solution a;
		a = queue.get(0);
		queue.remove(0);
		return a;
		
	}
	public boolean isEmpty(){
		if (queue.size()==0){
			return true;
		}
		return false;
	}
	/*public String toString(){
		String result="";
		for(int i=0;i<queue.size();i++){
			result=result+queue.get(i)+"";
		}
		return result;
	}*/
}