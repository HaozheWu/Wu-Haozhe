/**
 * The class <b>Solution</b> is used
 * to store a (partial) solution to the game
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 */
public class Solution{ 
	boolean[][] a;
	int width;
	int height;
	int counttotal=0;
    /**
     * Constructor. Creates an instance of Solution 
     * for a board of size <b>widthxheight</b>. That 
     * solution does not have any board position
     * value explicitly specified yet.
     *
     * @param width
     *  the width of the board
     * @param height
     *  the height of the board
     */
	Solution(int width,int height){
		this.width =width;
		this.height = height;
		boolean[][] a;
		a= new boolean[height][width];
		this.a =a;
		}
	/**
     * Constructor. Creates an instance of Solution 
     * wich is a deep copy of the instance received
     * as parameter. 
     *
     * @param other
     *  Instance of solution to deep-copy
       */
	Solution(Solution other ){
		boolean[][] c;
		c= new boolean[other.height][other.width];
		for (int i=0;i<other.height;i++) {
			for(int j=0;j<other.width;j++) {
				c[i][j]=other.a[i][j];
			}
		}
		this.a=c;
		this.width=c[0].length;
        this.height=c.length;
        this.counttotal=other.counttotal;

	}

    /**
     * returns <b>true</b> if and only the parameter 
     * <b>other</b> is referencing an instance of a 
     * Solution which is the ``same'' as  this 
     * instance of Solution (its board as the same
     * values and it is completed to the same degree)
     *
     * @param other
     *  referenced object to compare
     */
	public boolean equals(Object other){
		 if(other == null){
	            return false;
	        }
		 Solution newSolution =(Solution) other;
	        if(this.width != newSolution.width || this.height != newSolution.height){
	            return false;
	        }

	        for(int i = 0;i<height;i++){
	            for(int j = 0; j < width; j++){
	                if(this.a[i][j]!= newSolution.a[i][j]){
	                    return false;
	                }
	            }
	        }

	        return true;
	        

    }
	/** 
	    * specifies the ``next'' value of the 
	    * solution. 
	    * The first call to setNext specifies 
	    * the value of the board location (1,1), 
	    * the second call specifies the value
	    *  of the board location (1,2) etc. 
	    *
	    * If <b>setNext</b> is called more times 
	    * than there are positions on the board, 
	    * an error message is printed out and the 
	    * call is ignored.
	    *
	    * @param nextValue
	    *  the boolean value of the next position
	    *  of the solution
	    */

	void setNext(boolean nextValue){
		int b,c;
		b=this.counttotal/this.width;
		c=this.counttotal%this.width;
		this.a[b][c]=nextValue;
		
			this.counttotal++;
			

		if(counttotal==(width*height)+1){
			System.out.print(" error message ");
		}
	}
	 /** 
	    * returns <b>true</b> if the solution 
	    * has been entirely specified
	    *
	    * @return
	    * true if the solution is fully specified
	    */
	public boolean isReady(){
		if(counttotal==this.width*this.height){
			return true;
		}
		
		return false;
	}
	/**
     * returns a string representation of the solution
     *
     * @return
     *      the string representation
     */
	public String toString(){
        String result;
        result="[";
        for(int i=0;i<height;i++){
            result=result+"[";
            for(int j=0;j<width;j++){
            		if(j==width-1&&i==height-1){
                    result=result+a[i][j]+"]";
            					}
            		else if(j==width-1){
                        result=result+a[i][j]+"],"+"\n";
            		}
                    else{
                    
                    result=result+a[i][j]+""+",";
                }}
            }
            result=result+"]";
        return result;
    }
    
    /**
    * returns <b>true</b> if the solution is completely 
    * specified and is indeed working, that is, if it 
    * will bring a board of the specified dimensions 
    * from being  entirely ``off'' to being  entirely 
    * ``on''.
    *
    * @return
    *  true if the solution is completely specified
    * and works
    */
    
    public boolean isSuccessful(){
    	int[][] middle;
    	middle= new int[this.height][this.width];
    	if(this.isReady()==false) {
    		return false;
    	}
    	if(height<2||width<2){
    		return false;
    	}
    	else{
    	for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
            	if(this.a[i][j]==true){
            	middle[i][j]=1;}
        }
    }
        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
            	if(this.a[i][j]==true){
            		if (j!=0){
            			middle[i][j-1]++;
            		}
            		if (j!=this.width-1){
            			middle[i][j+1]++;
            		}
            		if(i!=0){
            			middle[i-1][j]++;
            		}
            		if(i!=this.height-1){
            			middle[i+1][j]++;
            		}
            	}
            }
        }
         for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
            	if(middle[i][j]%2.0==0){
            		return false;
            	}
            }
		}
		return true; 
		}
    	}
    /**
     * returns <b>true</b> if the solution is completely 
     * specified and is indeed working, that is, if it 
     * will bring a board of the specified dimensions 
     * from being  entirely ``off'' to being  entirely 
     * ``on''.
     *
     * @return
     *  true if the solution is completely specified
     * and works
     */
    	 
    public boolean stillPossible(boolean nextValue) {
    	int num=0,leftnum=0;
    	if(counttotal<width) {
    		return true;
    	}
    	
    	else {	
    	if (counttotal%width==0){
              if(this.a[counttotal/width-1][counttotal%width]==true){
                	num++;
                	}
              if(this.a[counttotal/width-1][counttotal%width+1]==true){
      				num++;
              }
              if(nextValue==true) {
           	 	num++;
              }
              if(counttotal/width>1) {
      			if(this.a[counttotal/width-2][counttotal%width]==true){
                  	num++;
      			}
      			}
    		}
     
    	else if(counttotal%width==width-1){
        	   if(this.a[counttotal/width-1][counttotal%width]==true){
               	num++;
               	}
        	   if(this.a[counttotal/width-1][counttotal%width-1]==true){
     				num++;
              }   
        	   if(nextValue==true) {
            	 	num++;
        	   }
        	   if(counttotal/width>1) {
       			if(this.a[counttotal/width-2][counttotal%width]==true){
                   	num++;
       			}
       			}
             }
    
    	
    		
        	else {
        		   if(this.a[counttotal/width-1][counttotal%width]==true){
                  	num++;
                  	}
        		   if(this.a[counttotal/width-1][counttotal%width+1]==true){
        				num++;
                 }
        		   if(this.a[counttotal/width-1][counttotal%width-1]==true){
        				num++;
        		   }
        		   if(counttotal/width>1) {
           			if(this.a[counttotal/width-2][counttotal%width]==true){
                       	num++;
           			}
        		   }
        		   if(nextValue==true) {
                     	 	num++;
        		   }
           	   }
    	}
    	if (counttotal/width==height-1 && counttotal%width!=0) {
    		if(this.a[counttotal/width-1][counttotal%width-1]==true) {
    			leftnum++;
    		}
    		if(this.a[counttotal/width][counttotal%width-1]==true) {
    			leftnum++;
    		}
    		if(nextValue==true) {
     			leftnum++;
    		}
    		if(counttotal%width>1) {
    			if(this.a[counttotal/width][counttotal%width-2]==true) {
        			leftnum++;
    		}
    	}
    	}
   
    	if(counttotal/width==height-1&&counttotal%width!=0){
    		return (num%2!=0&&leftnum%2!=0);
   	 		}
    	else {
    		return (num%2!=0);
		}
    }
    
    public boolean finish() {
    	int[] aa =new int[width];
    	while(this.counttotal/width<height) {
    		for(int l=0;l<width;l++) {
    				if(this.a[counttotal/width-1][l]==true) {
    					aa[l]=1;
    				}
    		}
    		if(this.a[counttotal/width-1][0]==true) {
				aa[1]++;
			}
			if(this.a[counttotal/width-1][width-1]==true) {
				aa[width-2]++;
			}
    		for(int i=1;i<width-1;i++) {
				if(this.a[counttotal/width-1][i]==true) {
					aa[i-1]++;
					aa[i+1]++;
				}
    		}
			if(this.counttotal/width>1) {
				for(int j=0;j<width;j++) {
				if(this.a[counttotal/width-2][j]==true) {
					aa[j]++;
					}
				}
			}
    		for(int k=0;k<width;k++) {
    			if(aa[k]%2==0) {
    				this.setNext(true);
    				if(k==width-1) {
    					aa=new int[width];
    				}
    			}
    			else {
    				this.setNext(false);
    				if(k==width-1) {
    					aa=new int[width];
    				}
    				}
    			}
    	
    		}
    	for(int l=0;l<width;l++) {
    		if(this.a[counttotal/width-1][l]==true) {
				aa[l]=1;
				}
    		}
    	if(this.a[counttotal/width-1][0]==true) {
    				aa[1]++;
    			}
    	if(this.a[counttotal/width-1][width-1]==true) {
    				aa[width-2]++;
    			}
    	for(int i=1;i<width-1;i++) {
    		if(this.a[counttotal/width-1][i]==true) {
    				aa[i-1]++;
    				aa[i+1]++;
    				}
    			}
    	if(this.counttotal/width>1) {
    		for(int j=0;j<width;j++) {
    			if(this.a[counttotal/width-2][j]==true) {
    				aa[j]++;
    				}
    			}
    		}
    	for(int k=0;k<width;k++) {
        		if(aa[k]%2==0) {
        			return false;
        			}
    	}
    	return true;
    }
}
  
             