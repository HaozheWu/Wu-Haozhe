
/**
 * The class <b>Solution</b> is used
 * to store a (partial) solution to the game
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 */
public class Solution {


    // Your variables here
    boolean[][] mySolution;
    int width;
    int height;
    int counterW;
    int counterH;

 
    /**
     * Constructor. Creates an instance of Solution 
     * for a board of size <b>widthxheight</b>. That 
     * solution does not have any board position
     * value explicitly specified yet.
     *
     * @param width
     *  the width of the board
     * @param height
     *  the height of the board
     */
    public Solution(int width, int height) {

        //Your code here
        mySolution =  new boolean[height][width];
        this.width = width;
        this.height = height;
        counterH = 1;
        counterW = 1;

        
    }

   /**
     * Constructor. Creates an instance of Solution 
     * wich is a deep copy of the instance received
     * as parameter. 
     *
     * @param other
     *  Instance of solution to deep-copy
     */
     public Solution(Solution other) {
        
     	mySolution = new boolean[other.height][other.width];
        this.height = other.height;
        this.width  = other.width;
     	for (int i=0;i<height;i++){
     		for(int j = 0;j<width;j++){
     			mySolution[i][j] = other.mySolution[i][j];
     		}
     	}
        this.counterW = other.counterW;
        this.counterH = other.counterH;

        //Your code here
        
    }


    /**
     * returns <b>true</b> if and only the parameter 
     * <b>other</b> is referencing an instance of a 
     * Solution which is the ``same'' as  this 
     * instance of Solution (its board as the same
     * values and it is completed to the same degree)
     *
     * @param other
     *  referenced object to compare
     */

    public boolean equals(Object other){

        //Your code here
        if(other == null){
            return false;
        }

        Solution newSolution =(Solution) other;
        if(this.width != newSolution.width || this.height != newSolution.height){
            return false;
        }

        for(int i = 0;i<height;i++){
            for(int j = 0; j < width; j++){
                if(this.mySolution[i][j]!= newSolution.mySolution[i][j]){
                    return false;
                }
            }
        }

        return true;
        
    }


    /** 
    * returns <b>true</b> if the solution 
    * has been entirely specified
    *
    * @return
    * true if the solution is fully specified
    */
    public boolean isReady(){

        return (counterW-1 == width && counterH -1== height);
        //Your code here
        
    }

    /** 
    * specifies the ``next'' value of the 
    * solution. 
    * The first call to setNext specifies 
    * the value of the board location (1,1), 
    * the second call specifies the value
    *  of the board location (1,2) etc. 
    *
    * If <b>setNext</b> is called more times 
    * than there are positions on the board, 
    * an error message is printed out and the 
    * call is ignored.
    *
    * @param nextValue
    *  the boolean value of the next position
    *  of the solution
    */
    public void setNext(boolean nextValue) {
        if(counterH< height){
                if(counterW < width){
                    mySolution[counterH-1][counterW-1] = nextValue;
                    counterW ++;
                }
                else if(counterW == width){
                    mySolution[counterH-1][counterW-1] = nextValue;
                    counterH ++;
                    counterW = 1;
                }
                else{
                    System.out.println("Error. Out of range.");
                }
        }else if(counterH==height){
                if(counterW < width){
                        mySolution[counterH-1][counterW-1] = nextValue;
                        counterW ++;
            }
            else if(counterW == width){
                mySolution[counterH-1][counterW-1] = nextValue;
                counterW +=1;
                counterH +=1;
            }
            else{
                System.out.println("Error. Out of range.");
            }

        }
        else{
            System.out.println("Error. Out of range.");
        }

        //Your code here
        
    }
    
    /**
    * returns <b>true</b> if the solution is completely 
    * specified and is indeed working, that is, if it 
    * will bring a board of the specified dimensions 
    * from being  entirely ``off'' to being  entirely 
    * ``on''.
    *
    * @return
    *  true if the solution is completely specified
    * and works
    */
    public void countChange(int[][] list,int h,int w){
        list[h][w]++;
        if(h-1>-1){
            list[h-1][w]++;
        }
        if(w-1>-1){
            list[h][w-1]++;
        }
        if(w+1 < width){
            list[h][w+1]++;
        }
        if(h+1< height){
            list[h+1][w]++;
        }

    }

    public boolean isSuccessful(){

        //Your code here
        if (isReady() == false){
            return false;
        }

        int[][] check = new int[height][width];
        for(int i  = 0;i<height;i++){
            for(int j = 0;j<width;j++){
                if(mySolution[i][j] == true){
                    countChange(check,i,j);
                }
            }
        }
        for(int i = 0;i<height;i++){
            for(int j = 0;j <width;j++){
                if(check[i][j]%2 == 0){
                    return false;
                }
            }
        }
        return true;

    }


    /**
     * returns a string representation of the solution
     *
     * @return
     *      the string representation
     */
    public String toString() {
 
        //Your code here
        String myString = "";
        myString +="[";
        int i,j;
        for( i = 0;i<height;i++){
            myString += "[";
            for(j = 0;j<width;j++){
                myString += mySolution[i][j]+",";
            }
            if(i==height-1 && j==width){
                myString +="]";
                
            }else{
                myString +="]"+ "\n";
                
            }
            
        }
        myString += "]";
        return myString;
    }

}
