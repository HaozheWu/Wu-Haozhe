import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GraphicalView extends JFrame implements View {
	private JLabel input;
	private Counter model;
	public GraphicalView (Counter model, Controller controller) {
		setLayout (new GridLayout(1 ,3));
		this.model = model;
		JButton button;
		button = new JButton("Increment");
		button.addActionListener(controller);
		add(button);
		JButton reset;
		reset = new JButton ( "Reset" );
		reset.addActionListener ( controller );
		add(reset);
		input = new JLabel ();
		add(input);
		
		//setup
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 100);

		//display the window
		setVisible(true);
	}
	public void update () {
	input.setText(Integer.toString(model.getValue())) ;
	}
}