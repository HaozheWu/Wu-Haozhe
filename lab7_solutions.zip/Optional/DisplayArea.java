
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JRadioButton;

import javax.swing.JPanel;

public class DisplayArea extends JPanel implements ActionListener {

    public static final int DISPLAY_SIZE = 500;
    private static final int DELTA = 10;

    private Color currentColor;
    private Point currentLocation;
    private boolean useDot = true;

    public DisplayArea(){
    	setBackground(Color.WHITE);
		currentColor = Color.RED;
		currentLocation = new Point(DISPLAY_SIZE/2, DISPLAY_SIZE/2);
    }

    public Dimension getPreferredSize() {
        return new Dimension(DISPLAY_SIZE,DISPLAY_SIZE);
    }

 
    public void paint(Graphics g) {
	super.paint(g);
	g.setColor( currentColor );
	if(useDot){
		g.fillOval( currentLocation.x - 5, currentLocation.y - 5, 10, 10 );
	}
	else{
		g.fillRect(currentLocation.x - 10, currentLocation.y - 10, 20, 20);
	}
    }	

    @Override
    @SuppressWarnings("unchecked")

    public void actionPerformed(ActionEvent e) {

	if (e.getSource() instanceof JButton) {
	    String cmd = e.getActionCommand();  
	    if ( cmd.equals( "Left" ) ) {
		currentLocation.x = ( DISPLAY_SIZE+(currentLocation.x - DELTA)) % DISPLAY_SIZE; 
	    } else if ( cmd.equals( "Right" ) ) {
		currentLocation.x = ( currentLocation.x + DELTA ) % DISPLAY_SIZE;
	    } else if ( cmd.equals( "Up" ) ) {
		currentLocation.y = ( DISPLAY_SIZE+(currentLocation.y - DELTA) ) % DISPLAY_SIZE;
	    } else if ( cmd.equals( "Down" ) ) {
		currentLocation.y = ( currentLocation.y + DELTA ) % DISPLAY_SIZE;
	    }
	} else if (e.getSource() instanceof JComboBox) {

	    JComboBox cb = (JComboBox) e.getSource();
	    String color = (String) cb.getSelectedItem();

	    if(color == "red"){
		currentColor = Color.RED;
	    } else if (color == "black"){
		currentColor = Color.BLACK;
	    } else if (color == "blue"){
		currentColor = Color.BLUE;
	    } else if (color == "green"){
		currentColor = Color.GREEN;
	    } else if (color == "yellow"){
		currentColor = Color.YELLOW;
	    }
	} else if (e.getSource() instanceof JRadioButton) {
		String cmd = e.getActionCommand();  
	    if ( cmd.equals( "Dot" ) ) {
		 	useDot=true;
	    } else {
		 	useDot=false;	  
	    } 
	
	}

	repaint();
    }
	
}
