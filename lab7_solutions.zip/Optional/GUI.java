/**
 * A new version of sample for Lab 4 course ITI1121
 * 
 * @Author : Vahdat Abdelzad/2016.
 */


import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;


public class GUI extends JFrame {
	

  
    @SuppressWarnings("unchecked")
  
    public GUI(){
	super("Lab4: Moving the red dot");

	// Set-up
		
	setBackground(Color.white);
	setDefaultCloseOperation(EXIT_ON_CLOSE);

	DisplayArea display = new DisplayArea();
	add(display,BorderLayout.CENTER);


	JButton bLeft, bRight, bUp, bDown;
	
	bLeft = new JButton( "Left" );
	bRight = new JButton( "Right" );
	bUp = new JButton( "Up" );
	bDown = new JButton( "Down" );
	
	String[]colors = new String[] { "red", "black", "blue", "green", "yellow" };
	JComboBox colorList = new JComboBox(colors);
 	JRadioButton  dotButton = new JRadioButton("Dot");
 	dotButton.setActionCommand("Dot");
 	dotButton.setSelected(true);
 	JRadioButton  recButton = new JRadioButton("Rectangle");
 	recButton.setActionCommand("Rectangle");
 	recButton.setSelected(false);
	ButtonGroup group = new ButtonGroup();
    group.add(dotButton);
    group.add(recButton);



	// Creating a Panel to hold the controls

	JPanel directionButtonPanel = new JPanel();
	directionButtonPanel.setLayout(new GridBagLayout());
	GridBagConstraints c = new GridBagConstraints();
	c.gridx = 1;
	c.gridy = 0;
	directionButtonPanel.add( bUp,c);
	c.gridx = 0;
	c.gridy = 1;
	directionButtonPanel.add( bLeft,c);
	c.gridx = 2;
	c.gridy = 1;
	directionButtonPanel.add( bRight,c);
	c.gridx = 1;
	c.gridy = 2;
	directionButtonPanel.add( bDown,c);
	directionButtonPanel.setBackground(Color.WHITE);

	JPanel controlPanel =  new JPanel();
	controlPanel.add(directionButtonPanel);
	controlPanel.add(dotButton);
	controlPanel.add(recButton);
	controlPanel.add( colorList);
	controlPanel.setBackground(Color.WHITE);
	add(controlPanel,BorderLayout.SOUTH);

	// Register the listeners
		
	bLeft.addActionListener( display );
	bRight.addActionListener( display );	
	bUp.addActionListener( display );	
	bDown.addActionListener( display );	
	colorList.addActionListener( display );			
	recButton.addActionListener(display);
	dotButton.addActionListener(display);

	setResizable(false);
	pack();

    }
	
    public static void main(String[] args){
	GUI gui = new GUI();
	gui.setVisible(true);
    }
}
