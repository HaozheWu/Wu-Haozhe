import javax.swing.*;
import java.awt.*;

 public class MyFirstGUI{

  public static void main(String[] args){
	 
    JFrame myFrame = new JFrame();
    //set the title
    myFrame.setTitle("My first Window");
	
    //set the size to 500X300 pixels (width by heigth)
    myFrame.setSize(500, 300);
	
    //set the object to the middle of our screen
    myFrame.setLocationRelativeTo(null);
	
    //end program when user closes the window
    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	

		//create a panel
	JPanel myPanel = new JPanel();
	//add a label to the panel
	myPanel.add(new Label("My first panel"));
	//set panel background color
	myPanel.setBackground(Color.green);
	//add the panel to the frame
	myFrame.add(myPanel, BorderLayout.NORTH);
	
	

	
		//create a panel
	JPanel myPanel2 = new JPanel();
	//add a label to the panel
	//myPanel2.add(new Label("My second panel"),BorderLayout.SOUTH);
	//set panel background color
	myPanel2.setBackground(Color.orange);
	//add the panel to the frame
	myFrame.add(myPanel2, BorderLayout.EAST);
	
		//create a panel
	JPanel myPanel3 = new JPanel();
	//add a label to the panel
	myPanel3.add(new Label("My third panel"));
	//set panel background color
	myPanel3.setBackground(Color.yellow);
	//add the panel to the frame
	myFrame.add(myPanel3, BorderLayout.SOUTH);
	
	
		
			//create a button
	JButton myButton = new JButton("Start");
	//set button background color
	myButton.setBackground(Color.white);
	//add the button to the pannel
	myPanel2.add(myButton);
				//create a button
	JButton myButton2 = new JButton("End");
	//set button background color
	myButton2.setBackground(Color.red);
	//add the button to the pannel
		myPanel2.add(myButton2);

	
	
	//set the window to visible      
    myFrame.setVisible(true);
	
	
  }


}