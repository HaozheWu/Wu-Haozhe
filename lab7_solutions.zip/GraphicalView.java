import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GraphicalView extends JFrame implements View {
	private JLabel input;
	private Timer model;
	public GraphicalView (Timer model, Controller controller) {
		setLayout (new GridLayout(2, 3));
		this.model = model;
		JButton incHours;
		incHours = new JButton("IncrementHours");
		incHours.addActionListener(controller);
		add(incHours);
		
		JButton incMin;
		incMin = new JButton("IncrementMinutes");
		incMin.addActionListener(controller);
		add(incMin);
		
		JButton incSec;
		incSec = new JButton("IncrementSeconds");
		incSec.addActionListener(controller);
		add(incSec);
		
		input = new JLabel();
		add(input);
		
		JButton decHours;
		decHours = new JButton("DecrementHours");
		decHours.addActionListener(controller);
		add(decHours);
		
		JButton decMin;
		decMin = new JButton("DecrementMinutes");
		decMin.addActionListener(controller);
		add(decMin);
		
		JButton decSec;
		decSec = new JButton("DecrementSeconds");
		decSec.addActionListener(controller);
		add(decSec);
		
		
		
		
		//setup
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(700, 100);

		//display the window
		setVisible(true);
	}
	public void update () {
	input.setText(model.toString());
}
}