Student name: Haozhe Wu
Student number: 300010064
Course code: ITI1121
Lab section: A-01

This archive contains the 5 files of lab 9, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.
