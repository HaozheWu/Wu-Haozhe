public class Customer {

    // Constant

    private static final int MAX_NUM_ITEMS = 25;

    // Instance variables

    private int arrivalTime;
    private int numberOfItems;
    private int initialNumberOfItems;

    // Constructor

    public Customer( int arrivalTime ) {
        // Your code here.
    	this.arrivalTime=arrivalTime;
    	this.numberOfItems =  (int) ( ( MAX_NUM_ITEMS - 1 ) * Math.random() ) + 1;
    	this.initialNumberOfItems=getNumberOfItems();
    }

    // Access methods

  
	public int getArrivalTime() {
        return arrivalTime;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public int getNumberOfServedItems() {
    	return this.initialNumberOfItems-this.numberOfItems;
        // Your code here.
    }

    public void serve() {
    	this.numberOfItems=numberOfItems-1;
        // Your code here.
    }
}