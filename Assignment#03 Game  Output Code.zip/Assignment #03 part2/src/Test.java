import javax.swing.JOptionPane;

public class Test {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		boolean correct=false;
		boolean correct1=false;
		Object a="Not Set Yet";
		Object b="Not Set Yet";
		while (correct!=true&&a!=null){
			correct=true;
			a=JOptionPane.showInputDialog(null,"Please Input the width of the Game Board��\n","Game Begin",JOptionPane.PLAIN_MESSAGE,null,null, "Input width here");
			if(a==null) {
				break;
			}
			try{
			int num=Integer.valueOf((String)a);
			} 
			catch (Exception e) {
				correct=false;
				JOptionPane.showMessageDialog(null, "Incorrect Width,Press Try Again", "Error",JOptionPane.ERROR_MESSAGE);
			}
		}
		while (correct1!=true&&b!=null&&a!=null){
			correct1=true;
			b=JOptionPane.showInputDialog(null,"Please Input the Height of the Game Board��\n","Game Begin",JOptionPane.PLAIN_MESSAGE,null,null, "Input width here");
			if(b==null) {
				break;
			}
			try{
			int num2=Integer.valueOf((String)b);
			} 
			catch (Exception e) {
				correct1=false;
				JOptionPane.showMessageDialog(null, "Incorrect Height,Press Try Again", "Error",JOptionPane.ERROR_MESSAGE);
				
			}
		}
		if(a==null||b==null) {
			System.exit(0);
		}
		int a1=Integer.valueOf((String)a);
		int b1=Integer.valueOf((String)b);
		if(a1<=2||b1<=2) {
			JOptionPane.showMessageDialog(null, "That's will be too easy for you, System will change The width and Height to 3", "Warning!",JOptionPane.WARNING_MESSAGE);
			a1=3;
			b1=3;
		}
		if(a1>16||b1>16) {
			JOptionPane.showMessageDialog(null, "That's will be too Hard for you, System will change The width and Height to 10", "Warning!",JOptionPane.WARNING_MESSAGE);
			a1=10;
			b1=10;
		}
		GameController f=new GameController(a1,b1);
		
		
	}
	
}	


	


	

