public class GameModel {

    /**
     * The number of column of the game.
     */
    private  int widthOfGame;
 
    /**
     * The number of lines of the game.
     */
    private  int heightOfGame;
 
    /**
     * A 2 dimentionnal array of widthOfGame*heightOfGame 
     * recording the state of the game. FALSE is OFF.
     */
	private boolean[][] model;

    /**
     * Constructor to initialize the model to a given size of board.
     * 
     * @param width
     *            the width of the board
     * 
     * @param height
     *            the height of the board
     * 
     */
    public GameModel(int width, int height) {
        
        widthOfGame = width;
        heightOfGame = height;
        // default boolean value = false == out
        model = new boolean[heightOfGame][widthOfGame]; 
    }



    /**
     * Getter method for the height of the game
     * 
     * @return the value of the attribute heightOfGame
     */   
    public int getHeight(){
        return heightOfGame;
    }

    /**
     * Getter method for the width of the game
     * 
     * @return the value of the attribute widthOfGame
     */   
    public int getWidth(){
        return widthOfGame;
    }


  /**
     * returns true if the dot  at row i and
     * column j in the model is ON, false otherwise
     * 
     * @param i
     *            the row of the dot in the model
     * @param j
     *            the column of the dot in the model
     * @return the status of the dot at location (i,j)in the model
     */   
    public boolean isON(int i, int j){
        if(i < 0 || i >= heightOfGame) {
            throw new IllegalArgumentException("Error, wrong row: " + i);
        }
        if(j < 0 || j >= widthOfGame) {
            throw new IllegalArgumentException("Error, wrong column: " + j);
        } 
        return model[i][j];
    }

    /**
     * Resets the model to all OFF. 
     */
    public void reset(){

        for(int i = 0; i < heightOfGame; i++){
            for(int j = 0; j < widthOfGame; j++){
                model[i][j] = false;
            }
        }
    }


  /**
     * Sets the location (i,j) to value
     * 
     * @param i
     *            the x coordinate of the dot
     * @param j
     *            the y coordinate of the dot
     * @param value 
     *      the value of the dot at location (i,j)
     */   
    public void set(int i, int j, boolean value){
        if(i < 0 || i >= widthOfGame) {
            throw new IllegalArgumentException("Error, wrong width: " + i);
        }
        if(j < 0 || j >= heightOfGame) {
            throw new IllegalArgumentException("Error, wrong height: " + j);
        } 
        model[j][i] = value;
    }


   /**
     * Builds a String representation of the model
     *
     * @return String representation of the model
     */
    public String toString(){
        StringBuffer b = new StringBuffer();
        for(int j = 0; j < heightOfGame; j++){
            b.append("[");
            for(int i = 0; i < widthOfGame; i++){
                if (i>0) {
                    b.append(",\t");
                }
                b.append(model[j][i]);
            }
            b.append("]\n");
        }
        return b.toString();
    }
}
