Student name: Haozhe Wu
Student number: 300010064
Course code: ITI1121
Lab section: A-01

This archive contains the 7 files of lab 8, that is, this file (README.txt),
plus RandomExceptions.Java, Account.java, NotEnoughMoneyException.java, Map.java, Pair.java, Dictionary.java.