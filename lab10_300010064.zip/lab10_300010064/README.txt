Student name: Haozhe Wu
Student number: 300010064
Course code: ITI1121
Lab section: A-01

This archive contains the 3 files of lab 10, that is, this file (README.txt),
plus OrderedStructure.java, OrderedList.java.
