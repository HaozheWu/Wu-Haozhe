﻿This assignment was done by a group of two students.

 
Author: Shifeng Song and Wu Haozhe                         
Student #: 300018788 and  300010064                         
Courese:    ITI 1121-A | ITI 1121-A
                        *
This assignment contains 20 files.
 01/GameModel.java
• 01/LightsOut.java
• 01/Q1Tests.java
• 01/Queue.java
• 01/QueueImplementation.java
• 01/Solution.java
• 01/StudentInfo.java
• 02/GameController.java
• 02/GameModel.java
• 02/GameView.java
• 02/GridButton.java
• 02/LightsOut.java
• 02/Queue.java
• 02/QueueImplementation.java
• 02/Solution.java
• 02/StudentInfo.java
• 02/Icons/Light-0.png
• 02/Icons/Light-1.png
• 02/Icons/Light-2.png
• 02/Icons/Light-3.png