// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;

import javax.swing.ComboBoxEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.plaf.ComboBoxUI;

import java.awt.event.ItemEvent;

// YOUR OTHER IMPORTS HERE IF NEEDED

/**
 * The class <b>GameController</b> is the controller of the game. It is a listener
 * of the view, and has a method <b>play</b> which computes the next
 * step of the game, and  updates model and view.
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 */


public class GameController implements ActionListener, ItemListener {
	GameModel a;
	GameView b;
	


    // YOUR VARIABLES HERE
    /**
     * Constructor used for initializing the controller. It creates the game's view 
     * and the game's model instances
     * 
     * @param width
     *            the width of the board on which the game will be played
     * @param height
     *            the height of the board on which the game will be played
     */
    public GameController(int width, int height) {
    	a=new GameModel(width,height);
    	b=new GameView(a,this);
    	b.update();
    }


    /**
     * Callback used when the user clicks a button (reset, 
     * random or quit)
     *
     * @param e
     *            the ActionEvent
     */

    public void actionPerformed(ActionEvent e) {
    	if (e.getSource() instanceof GridButton) {
    		a.click((((GridButton) e.getSource()).getColumn()), ((GridButton)(e.getSource())).getRow());
    		b.update();
    	}
    	
    	else if (e.getSource() instanceof JButton) {
            JButton clicked = (JButton)(e.getSource());
            if (clicked.getText().equals("Quit")) {
                System.exit(0);
            }else if (clicked.getText().equals("Reset")){
               this.reset();
            }
            else if (clicked.getText().equals("Random")){
               this.random();
          }
    	}

    }
    private void reset(){
        a.reset();
        b.buttonSolution.setState(false);
        b.update();
    }
    public void random() {
    	a.randomize();
    	a.count=0;
    	b.update();
    	
    }
    public void Solution() {
    	a.setSolution();
    	b.update();
    }

    /**
     * Callback used when the user select/unselects
     * a checkbox
     *
     * @param m
     *            the ItemEvent
     */
	@Override
	public void itemStateChanged(ItemEvent m) {
	 
    		this.Solution();
		
	}


	public void finish(int n) {
		if(n==0) {
			this.reset();
		}
		if(n==1) {
			System.exit(0);
		}
		
	}
   




    // YOUR OTHER METHODS HERE

}
