// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3
import java.util.ArrayList;
import java.util.Random;

public class GameModel {
	public  int width;
	public  int height;
	public 	boolean[][] board;
	public 	int count;
	public 	Solution a;
	private ArrayList<Solution> b;
	public GameModel(int width, int height) {
		this.board=new boolean[height][width];
		this.height=height;
		this.width=width;
		this.count=0;
	}

	public  int getHeight() {
		return height;
	}
	public   int getWidth() {
		return width;
	}
	public boolean isON(int i,int j) {
		return this.board[i][j];
	}
	public void reset() {
		this.board=new boolean[height][width];
		this.count=0;
	}
	public void set(int i, int j, boolean value) {
		this.board[j][i]=value;
	}
	public String toString() {
		  StringBuffer out = new StringBuffer();
	        out.append("[");
	        for(int i = 0; i < height; i++){
	            out.append("[");
	            for(int j = 0; j < width ; j++) {
	                if (j>0) {
	                    out.append(",");
	                }
	                out.append(board[i][j]);
	            }
	            out.append("]"+(i < height -1 ? ",\n" :""));
	        }
	        out.append("]");
	        return out.toString();
	    }

	public void click(int i, int j) {
		this.set(i,j,!isON(j,i));
		this.count++;
		if(i!=0) {
			this.set(i-1,j,!isON(j,i-1));
		}
		if(j!=0) {
			this.set(i,j-1,!isON(j-1,i));
		}
		if(i!=this.width-1) {
			this.set(i+1,j,!isON(j,i+1));
		}
		if(j!=this.height-1) {
			this.set(i,j+1,!isON(j+1,i));
		}
	}
	public int getNumberOfSteps() {
		return this.count;
	}
	public void randomize() {
		for (int j = 0; j <this.height; j++) {
            for (int i = 0; i <this.width; i++) {
            	int num =(int)(Math.random() * 2);
            	if(num<=0.5) {
            		this.set(i,j,false);
            	}
            	if(num>0.5) {
            		this.set(i,j,true);
            	}
            	
            }
		}
		while (LightsOut.solve(this).size()==0){
			for (int j = 0; j <this.height; j++) {
	            for (int i = 0; i <this.width; i++) {
	            	int num =(int)(Math.random() * 1);
	            	if(num==0) {
	            		this.set(i,j,false);
	            	}
	            	if(num==1) {
	            		this.set(i,j,true);
	            	}
	            	
	            }
			}
		}
		
	}
	public void setSolution(){
		if(LightsOut.solveShortest(this)==null) {
			System.out.println("No Solution For this Case, System help to Reset");
			this.board=new boolean[height][width];
		}
		this.a=LightsOut.solveShortest(this);
		
	}
	public boolean solutionSelects(int i, int j) {
		return a.get(j,i);
	}
	
	
	
	
}
