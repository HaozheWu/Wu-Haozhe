import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;



// your other import here if needed

/**
 * The class <b>GameView</b> provides the current view of the entire Game. It extends
 * <b>JFrame</b> and lays out a matrix of <b>GridButton</b> (the actual game) and 
 * two instances of JButton. The action listener for the buttons is the controller.
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 * @param <DotButton>
 */

// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3

public class GameView extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private JLabel input;
	public GameModel a;
	private GridButton[][] board;
	private JLabel nbreOfStepsLabel;
	public Checkbox buttonSolution;
	public Solution b;
	public GameController aaa;
	public GameView(GameModel a, GameController gameController) {
		this.aaa=gameController;
    	this.a=a;
    	setTitle("ITI1121");
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setBackground(Color.WHITE);
    	JPanel panel = new JPanel();
    	panel.setBackground(Color.WHITE);
        panel.setLayout(new GridLayout((a.getHeight()), (a.getWidth())));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));
        board = new GridButton[a.getWidth()][a.getHeight()];
        for (int j = 0; j < a.getHeight(); j++) {
            for (int i = 0; i <a.getWidth(); i++) {
                board[i][j] = new GridButton(i,j);
                board[i][j].setState(a.isON(j, i), false);
                board[i][j].addActionListener(gameController);
                panel.add(board[i][j]);
            }
            
        }
        add(panel, BorderLayout.CENTER);
        
        JButton buttonReset = new JButton("Reset");
        buttonReset.setFocusPainted(false);
        buttonReset.addActionListener(gameController);
        
        JPanel panel1 = new JPanel();
        panel.setBackground(Color.WHITE);
        this.buttonSolution = new Checkbox("Solution");
        buttonSolution.setFocusable(false);
        buttonSolution.addItemListener(gameController);
        
        
        JButton buttonExit = new JButton("Quit");
        buttonExit.setFocusPainted(false);
        buttonExit.addActionListener(gameController);
        JButton buttonRandom = new JButton("Random");
        buttonRandom.setFocusPainted(false);
        buttonRandom.addActionListener(gameController);
        
        nbreOfStepsLabel = new JLabel();
        
        add(nbreOfStepsLabel,BorderLayout.SOUTH);
        JPanel control = new JPanel();
        control.setLayout(new GridLayout(5,1));
        
        control.setBackground(Color.WHITE);
        input = new JLabel();
        
        control.add(input);
        control.add(buttonReset);
 
        control.add(buttonRandom);
        panel1.add(buttonSolution);
        control.add(panel1);
        
        control.add(buttonExit);
        
        add(control, BorderLayout.EAST);
       
    	pack();
    	setVisible(true);
	

    }

    

 

	/**
     * updates the status of the board's GridButton instances based 
     * on the current game model, then redraws the view
     */
    public void update(){
    	boolean finish=true;
    	if (solutionShown()==false) {
    	for(int i=0;i<a.getWidth();i++) {
    		for(int j=0;j<a.getHeight();j++) {
    			
    			 board[i][j].setState(a.isON(j,i), false);
    			 if(this.a.board[j][i]==false) {
    				 finish=false;
    			 }
    		}
    	
    	}
         
        nbreOfStepsLabel.setText("Number of steps: " + a.getNumberOfSteps());
        repaint();
    	}
    	if (solutionShown()==true) {
    		a.setSolution();
    		for(int i=0;i<a.getWidth();i++) {
        		for(int j=0;j<a.getHeight();j++) {
        			 board[i][j].setState(a.isON(j,i), a.solutionSelects(i, j));
        			 if(this.a.board[j][i]==false) {
        				 finish=false;
        			 }
        		}
        	}
    		
            nbreOfStepsLabel.setText("Number of steps: " + a.getNumberOfSteps());
            repaint();
    	}
    	if(finish){
		Object[] options = {"PLAY AGAIN","QUIT"};
		int n=JOptionPane.showOptionDialog(null, "You Have Win The Game, You Use "+a.count+" Steps","Congratulations! You Won", 
			JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			aaa.finish(n);			
				}
				
    	  }
    	

    /**
     * returns true if the ``solution'' checkbox
     * is checked
     *
     * @return the status of the ``solution'' checkbox
     */

    public boolean solutionShown(){
    	return buttonSolution.getState();
    }


   
  
	
}
