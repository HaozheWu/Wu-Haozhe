// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3

public interface Queue<E> {
	boolean isEmpty();
	E dequeue();
	void enqueue(E a);
}
     