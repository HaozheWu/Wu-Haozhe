/**
* Contains a method <code>void display()</code> that all the <code>main</code>
* methods call to show the student information. Fill the box with your personal
* information.
*
* @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
*/

// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3

public class StudentInfo {

    /**
    * Displays the student information: student name, id, section, etc for each
    * member of the team.
    */

    public static void display() {

        System.out.println("************************************************************");
        System.out.println("*  Author: Shifeng Song| Wu Haozhe                         *");
        System.out.println("*  Student #: 300018788| 300010064                         *");
        System.out.println("*  Courese: ITI 1121-A | ITI 1121-A                        *");
        System.out.println("*  Assignemnt:3                                            *");
        System.out.println("************************************************************");
        System.out.println();
// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3

    }

}
