/**
 * The class <b>Gmane</b> is used
 * capture the current state of theboard.
 *
 * @author Shifeng.Song.Wu HaoZhe.University.of.Ottawa.
 */
// Author: Shifeng Song, Wu HaoZhe
// Student number: 300018788,300010064
// Course: ITI 1121-A
// Assignment: 3

public class GameModel {

	/** 
	* our board
	*/
 	private  boolean [][] board ;

 	/**
 	* width of the board
 	*/
 	private int width;

 	/**
 	* height of the board
 	*/
 	private int height;



	/** the constructor,  
	 * Creates an all OFF game of width width 
	 * and of height height.
	 *
	 * @param width
	 * 			the width of board
	 * @param height
	 * 			the height of board
	 */
	public GameModel(int width, int height){
		this.width = width;
		this.height = height;
		board = new boolean[this.height][this.width];
	}

	/** 
	* return the height of board
	* @return 
	*	the height of board
	*/
	public int getHeight(){
		return this.height;
	}

	/** 
	* return the width of board
	* @return 
	*	the width of board
	*/
	public int getWidth(){
		return this.width;
	}

	/** returns <b>true<b> if the location at
	* row i and column j is ON
	* @param i
	* 	postion at row i
	* @param j
	* 	postion at column j
	* @return
	* 	true if the given position is ON
	*/
	public boolean isON(int i, int j){
		return board[i][j];
	}

	/** 
	* reset board to all OFF.
	*/
	public void reset(){
		board = new boolean[this.height][this.width];
		
	}

	/**
	* sets the location(i,j) of the board to value
	* @param i
	*	cow i
	* @param j
	* 	column j
	* @param value
	* 	given boolean value
	*/

	
	public void set(int i, int j, boolean value){
		board[j][i] = value;
		
	}

	/**
     * returns a string representation of the board
     *
     * @return
     *      the string representation
     */
    public String toString() {
        StringBuffer myString = new StringBuffer();
        myString.append("[");
        for(int i = 0; i < height; i++){
            myString.append("[");
            for(int j = 0; j < width ; j++) {
                if (j>0) {
                    myString.append(",");
                }
                myString.append(board[i][j]);
            }
            myString.append("]"+(i < height -1 ? ",\n" :""));
        }
        myString.append("]");
        return myString.toString();
    }
}
