public class Q2{

	public static void main(String[] args){
		for (int i=1;i<31;i++){
			if(i%3==0 ){
				if(i%5==0){
				System.out.print(i );
				System.out.println(" FizzBuzz");
				}
				else{
					System.out.print(i);
					System.out.println(" Fizz");}
			}
			if(i%5==0){
				if(i%3!=0){
				System.out.print(i );
				System.out.println(" Buzz");
				}
			}
		}
	}
}	