public class Q3_ArrayInsertionDemo{

	public static int[] insertIntoArray(int[] beforeArray, int indexToInsert, int valueToInsert){
		// Your code here
		int[] result;
		result = new int[beforeArray.length+1];
		for (int i=0;i<indexToInsert;i++){
			result[i]=beforeArray[i];
		}
		result[indexToInsert]=valueToInsert;
		for (int i=indexToInsert; i<beforeArray.length;i++){
			result[i+1]=beforeArray[i];
		}
		return result;
	}
	public static void main(String[] args){
		// Your code here
		System.out.println("Array before insertion:");
		int[] beforeArray;
		beforeArray=new int[]{1,5,4,7,9,6};
		for (int i=0; i<beforeArray.length;i++){
			System.out.println(beforeArray[i]);
		}
		int indexToInsert=3;
		int valueToInsert=15;
		System.out.println("Array after insertion of "+valueToInsert+" at position "+indexToInsert+" :");
		for (int i=0;i<insertIntoArray(beforeArray,indexToInsert,valueToInsert).length;i++){
			System.out.println(insertIntoArray(beforeArray,indexToInsert,valueToInsert)[i]);
		}
	}
}