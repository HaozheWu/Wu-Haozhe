import java.util.Scanner;
public class Q6{
	public static int b;

	public static void main(String[] args){
		System.out.print("How many student number do you want to be tested ");
		Scanner a = new Scanner(System.in);
 		 b= a.nextInt();
		//your code here
		double result[];
		result=new double[b];
		for(int i=1;i<b+1;i++){
			System.out.println("Please type in student "+i+"  's grate");
		Scanner scanNum = new Scanner(System.in);
		double myDouble = scanNum.nextDouble();
		result[i-1]=myDouble;
	}
		System.out.print("what information do you want to know? input 0==Average  1==median  2==number-failed  3==number-passed ");
		Scanner scanNum = new Scanner(System.in);
 		int myInt = scanNum.nextInt();
 		if (myInt==0){
 			 System.out.println(calculateAverage(result));
 		}
 		if (myInt==1){
 			System.out.println(calculateMedian(result));
 		}
 		if (myInt==2){
 			System.out.println(calculateNumberFailed(result));
 		}
 		if (myInt==3){
 			System.out.println((calculateNumberPassed(result)));
 		}
 	
 	}




	public static double calculateAverage(double[] notes){
		double result=0.0;
		for (int i=0;i<b;i++){
			result=notes[i]+result;
		}
		result=result/b;
		return result;
		//your code here
	}

	public static double calculateMedian(double[] notes){
		//your code here

			int i, j,argMin;
			double  tmp;
			double result=0.0;

			for (i = 0; i < b-1; i++) {
				argMin = i;
				for (j = i + 1; j < b; j++) {
					if (notes[j] < notes[argMin]) {
						argMin = j;
					}
				}

			tmp = notes[argMin];
			notes[argMin] = notes[i];
			notes[i] = tmp;
			}
	if (b%2==0){
		result=notes[b/2]+notes[b/2-1];
		result=result/2;
		return result;
	}
	else{
		result=notes[((b-1)/2)];
		return result;
	}
		
	
	
		
	}

	public static int calculateNumberFailed(double[] notes){
		int result=0;
		for(int i=0;i<b;i++){
			if (notes[i]<50){
				result=result+1;
			}
		}
		return result;
		//your code here
	}

	public static int calculateNumberPassed(double[] notes){
		//your code here
	
		int result=0;
		for(int i=0;i<b;i++){
			if (notes[i]>=50){
				result=result+1;
			}
		}
		return result;
}
}