public class Q3_SquareArray{

	public static int[] createArray(int size) {
		// Your code here
		int[] createArray;
		createArray = new int[size];
		for(int i =0; i < size; i++){
			createArray[i] = i*i;
		}
		return createArray;


	}

	public static void main(String[] args){
		// Your code here
		int[] a = createArray(13);
		for(int i = 0; i < a.length; i++){
			System.out.println("The square of "+i +" is: "+a[i]);
		}
	}
}