public class Rational {

    private int numerator;
    private int denominator;


    // constructors

    public Rational(int numerator) {
	     this.numerator=numerator;
	     this.denominator=1;
	  
    }

    public Rational(int numerator, int denominator) {
    	if(denominator<0){
    		denominator=denominator*-1;
    		numerator=numerator*-1;
    		
    		}

    	if(denominator==0){
    		denominator=1;
    		numerator=0;
  			}

	     this.numerator=numerator;
	     this.denominator=denominator;
	 
		reduce();
	
    }

	     


    // getters

    public int getNumerator() {
	     return numerator;
    }

    public int getDenominator() {
	     return denominator;
    }


    // instance methods

    public Rational plus(Rational other) {
	     // Your code here
    	Rational result;
    	int a,b,c,d;
    	a=this.numerator*other.getDenominator();
    	b=this.denominator*other.getNumerator();
    	c=a+b;
    	d=this.denominator*other.getDenominator();
    	result=new Rational(c,d);
    	return result;
    }


    public static Rational plus(Rational a, Rational b) {
    	// Your code here
    	Rational result;
		int c,d,e,f;
    	c=a.getNumerator()*b.getDenominator();
    	d=a.getDenominator()*b.getNumerator();
    	e=c+d;
    	f=a.getDenominator()*b.getDenominator();
    	result=new Rational(e,f);
    	return result;
    }
    // Transforms this number into its reduced form

    private void reduce() {
    	int a;
  
    	if(this.getNumerator()<0){
    		a=gcd(-1*this.getNumerator(),this.getDenominator());
    		this.numerator=this.numerator/a;
    		this.denominator=this.denominator/a;
    	}
   		else if(this.getNumerator()>0){
    		a=gcd(this.getNumerator(),this.getDenominator());
    		if(a!=1){
    		this.numerator=this.numerator/a;
    		this.denominator=this.denominator/a;
    		}
    	}
    	}
    

    // Euclid's algorithm for calculating the greatest common divisor
    private int gcd(int a, int b) {
    	while (a != b)
    	    if (a > b)
    		     a = a - b;
    	    else
    		     b = b - a;
    	return a;
    }


    public int compareTo(Rational other) {
  
    	double a,b,c,d,e,f;
    	
    	a=this.numerator;
    	b=this.denominator;
    	c=other.numerator;
    	d=other.denominator;
    	e=a/b;
    	f=c/d;
    	if(e<f){
    		return -1;
    	}
    	else if(e>f){
    		return 1;
    	}
    	else{
    		return  0;
    }
      // Your code here
    }

    public boolean equals(Rational other) {
 
    	return this.numerator==other.numerator&&this.denominator==other.denominator;

      // Your code here
    }

    public String toString() {
    	String result;
    	if (denominator == 1) {
    	   result=this.numerator+"";
    	} else {
    	   result=(this.numerator)+""+"/"+this.denominator+"";
    	}
    	return result;
    }

}
