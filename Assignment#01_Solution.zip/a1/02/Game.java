/**
 * The class Game implements the logic of the single player game of Rummy.
 *
 * @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
 */

public class Game {

    // Instance variables
    
    private Deck deck;
    private Deck player;
    private Die die;

    /**
     * This constructor has one parameter, which speciﬁes the number
     * of ranks for this game. When a Game object is created, it also
     * creates the main deck and the die.
     *
     * @param ranks the number of values for the ranks
     */
    
    public Game(int ranks) {

        // pre-condition: ranks is a valid number
        
        die = new Die();
        deck = new Deck(ranks);
    }

    // Helper method for the case where the value of the die was 1.
    
    private void playOne() {

        Card card;
        card = null;

        boolean done;
        done = false;

        System.out.println("Discard any card of your choosing.");

        while (! done) {
            System.out.println("Which card would you like to discard?");
            card = Utils.readCard();
            if (! player.contains(card)) {
                System.out.println("No such card in your hand. Try again.");
            } else {
                done = true;
            }
        }

        player.remove(card);
        player.print();

    }

    // Helper methode for the case where the value of the die was not 1.
    
    private void playElse(int value) {

        boolean canPlay;

        System.out.println("Adding (up to) "+value+" cards to your hand.");

        player.addAll(deck.deal(value));
        player.print();

        canPlay = Utils.readYesOrNo("Do you  have a sequences of three or more cards of the same suit or two or more of a kind? ");

        while (canPlay) {

            Deck cards;

            cards = Utils.readCards("Which 3+ sequence or 2+ of a kind would you like to discard?");

            if (! player.containsAll(cards)) {
                System.out.println(cards + " is not valid!");
            } else if (cards.isKind() || cards.isSeq()) {
                player.removeAll(cards);
                player.print();
            } else {
                System.out.println("Cannot discard those cards!");
            }

            canPlay = Utils.readYesOrNo("Do you  have a sequences of three or more cards of the same suit or two or more of a kind? ");

        }

    }

    /**
     * Implements the logic of the game. See assignment description.
     *
     */
    
    public void play() {

        int rounds;
        rounds = 1;

        deck.shuffle();

        player = deck.deal(7);
        player.print();

        while (player.hasCards()) {

            System.out.println("Welcome to round " + rounds);

            if (deck.hasCards()) {

                System.out.println("Rolling the die!");
                die.roll();
                System.out.println("The die has value " + die.getValue());

                if (die.getValue() == 1) {
                    playOne();
                } else {
                    playElse(die.getValue());
                }

            } else {

                System.out.println("The game is in empty deck phase.");
                playOne();
                System.out.println("Round "+rounds+" completed.");

            }

            rounds++;
        }

        System.out.println("Congratulations, you completed the game in "+rounds+" rounds.");

    }

}
