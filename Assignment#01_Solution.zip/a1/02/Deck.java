/**
 * In this application, the programmer must often manipulate a
 * collection of cards: the main deck, the player’s hand, the cards
 * that are dealt, and the cards that user wants to discard. Having a
 * speciﬁc data structure for a collection of cards will be useful
 * when implementing the logic of the game.
 *
 * @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
 */

import java.util.ArrayList;
import java.util.Collections;

public class Deck {

    // Uses an object of the class ArrayList to store cards
    
    private ArrayList<Card> cards;

    /**
     * Used when creating an empty deck.
     */
    
    public Deck() {
        cards = new ArrayList<Card>();
    }

    /**
     * The parameter speciﬁes the number of ranks for the cards. The
     * constructor initializes this deck to contain 4 × range cards, where
     * range is the value of the parameter.
     *
     * @param range the number of values for range
     */
    
    public Deck(int range) {

        // pre-condition: range is a valid value

        this(); // calls the constructor with no parameters

        for (int suit=0; suit<4; suit++) {
            for (int rank=1; rank<=range; rank++) {
                cards.add(new Card(suit, rank));
            }
        }

    }

    /**
     * Returns the number of cards in this deck.
     *
     * @return the number of cards in this deck.
     */

    public int size() {
        return cards.size();
    }

    /**
     * Returns true if and only if this deck is not empty.
     *
     * @return true if and only if this deck is not empty.
     */

    public boolean hasCards() {
        return cards.size() > 0;
    }

    /**
     * Returns the card at the speciﬁed position in the deck.
     *
     * @param pos the specified position
     * @return the card at the speciﬁed position in the deck.
     */

    public Card get(int pos) {

        // pre-condition: 0 <= pos < size
        
        return cards.get(pos);
    }

    /**
     * Adds the speciﬁed card at the end of this deck.
     *
     * @param card the specified card
     */

    public void add(Card card) {

        // pre-condition: card != null
        
        cards.add(card);
    }

    /**
     * Appends all the cards from other at the end of this deck. The
     * cards are also removed from other. Consequently, the deck
     * designated by other is empty after the call.
     *
     * @param other an other deck of cards
     */

    public void addAll(Deck other) {

        // pre-condition: other != null && other != this

        while (other.size() > 0) {
            cards.add(other.removeFirst());
        }

    }

    /**
     * Removes and returns the last card of this deck.
     *
     * @return the last card of this deck.
     */

    public Card removeLast() {

        // pre-condition: this deck is not empty

        return cards.remove(cards.size()-1);
    }

    /**
     * Removes and returns the ﬁrst card of this deck.
     *
     * @return the ﬁrst card of this deck.
     */

    public Card removeFirst() {

        // pre-condition: this deck is not empty

        return cards.remove(0);
    }

    /**
     * Removes the ﬁrst occurrence of the speciﬁed card from this
     * deck, if it is present. Returns true if and only if this deck
     * contains the speciﬁed card.
     *
     * @param card the card to be removed
     * @return true if the card has been successfully removed
     */

    public boolean remove(Card card) {

        // pre-condition: card != null, Card implements equals(Object)
        
        return cards.remove(card);
    }

    /**
     * Removes from this deck all of its cards that are contained in
     * the deck designated by the parameter other. The cards are not
     * removed from the deck designated by other.
     *
     * @param other a reference to another deck
     */

    public void removeAll(Deck other) {

        // pre-condition: other != null, Card implements equals(Object)

        for (int i=0; i<other.size(); i++) {
            cards.remove(other.get(i));
        }

    }

    /**
     * Randomly permutes the cards.
     */

    public void shuffle() {
        Collections.shuffle(cards);
    }

    /**
     * Removes a maximum of n cards from the end of this deck. The
     * cards are returned in a new deck.
     *
     * @param n the number of cards to be removed
     * @return a new deck with the cards that have been removed
     */

    public Deck deal(int n) {

        // silently ignores negative values or values larger than size()-1

        Deck other;
        other = new Deck();

        while (n>0 && cards.size() > 0) {
            other.add(cards.remove(cards.size()-1));
            n--;
        }

        return other;

    }

    /**
     * Returns true if and only if this deck contains the speciﬁed card.
     *
     * @param card the card to be removed
     * @return true if this deck contains the specified card
     */

    public boolean contains(Card card) {

        // pre-conditon: card != null && Card implements equals(Object)
        
        return cards.contains(card);
    }

    /**
     * Returns true if and only if this deck contains all the cards in
     * the speciﬁed deck.
     *
     * @param other the reference of another deck
     * @return true if this deck contains all the cards
     */

    public boolean containsAll(Deck other) {

        // pre-condition: other != null && other != this

        for (int i=0; i<other.size(); i++) {
            if (! cards.contains(other.get(i))) {
                return false;
            }
        }

        return true;
    }

    /**
     *  Returns true if and only if this deck is a discardable
     *  kind. Speciﬁcally, the method returns true if this deck has at
     *  least two cards and all the cards have the same
     *  rank. Otherwise, the method returns false.
     *
     * @return true if and only if this deck is a discardable kind. 
     */

    public boolean isKind() {

        if (cards.size() < 2) {
            return false;
        }

        for (int i=1; i<cards.size(); i++) {
            if (cards.get(i-1).getRank() != cards.get(i).getRank()) {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns true if and only if this deck is a discardable
     * sequence. Speciﬁcally, the method returns true if this deck has
     * at least three cards, the cards all have the same suit, the
     * cards form a sequence of consecutive ranks. Otherwise, the
     * method returns false.
     *
     * @return true if and only if this deck is a discardable sequence.
     */

    public boolean isSeq() {

        if (cards.size() < 3) {
            return false;
        }

        sortByRank();

        for (int i=1; i<cards.size(); i++) {

            Card a, b;

            a = cards.get(i-1);
            b = cards.get(i);

            if (a.getSuit() != b.getSuit()) {
                return false;
            }

            if (a.getRank()+1 != b.getRank()) {
                return false;
            }

        }

        return true;
    }

    /**
     * Sorts the cards of this deck by rank, then by suit.
     *
     */

    public void sortByRank() {

        // Implementing your own sort is completely acceptable. Here,
        // we simply show you how to use the built-in sort.
        
        cards.sort(new ComparatorByRank());
    }

    /**
     * Sorts the cards of this deck by suit, then by rank.
     *
     */

    public void sortBySuit() {

        // Implementing your own sort is completely acceptable. Here,
        // we simply show you how to use the built-in sort.
        
        cards.sort(new ComparatorBySuit());
    }

    /**
     * Prints the content of this deck in two ways. First, the content
     * is printed by suit. Next, the content is printed by
     * rank. Please note that this method has a side eﬀect, the order
     * of the cards is not preserved. Consequently, the method should
     * not be called on the main deck during a game!
     */

    public void print() {    
        System.out.println("Here is your new deck printed in two ways:");
        sortByRank();
        System.out.println(toString());
        sortBySuit();
        System.out.println(toString());
    }

    /**
     * Overrides the method toString from the class Object. Returns a
     * string representation that contains all the cards in this deck.
     *
     * @return string representation of the deck
     */

    public String toString() {

        String out;
        out = "Deck [";

        for (int i=0; i<cards.size(); i++) {
            if (i>0) {
                out = out + ",";
            }
            out = out + cards.get(i);
        }

        out = out + "]";

        return out;
    }

}
