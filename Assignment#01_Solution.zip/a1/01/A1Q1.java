/**
 * In Java, implement the class method countPositive that takes as
 * input the reference of an array of numbers (all of type double) and
 * returns the number of elements of the designated array that are
 * positive (i.e. larger than 0). You will store this method in a
 * class called A1Q1. You can test your code using the program
 * A1Q1Test. This method does not read information from the user. It
 * obtains the necessary information through its parameter. The same
 * is true for all the methods in this part of the assignment.
 *
 * @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
 */

public class A1Q1 {

    /**
     * Returns the number of elements of the designated array that are
     * positive in the designated array.
     *
     * @param xs an array of numbers
     * @return the number of positive values
     */

    public static int countPositive(double[] xs) {

	if (xs == null) {
	    return 0;
	}
	
	int count;
	count = 0;

	for (int i=0; i<xs.length; i++) {
	    if (xs[i] > 0.0) {
		count = count + 1;
	    }
	}

	return count;
    }

}
