/**
 * In Java, implement a class method called hasLengthTwoRun that takes
 * as input the reference of an array of numbers (all of type double)
 * and returns true if the given array has at least one run (of length
 * at least two) of repeated and consecutive values, and false
 * otherwise. Make sure that the method is eﬃcient (i.e. it stops as
 * soon as the answer is known). You will store this method in a class
 * called A1Q2. You can test your code using the program A1Q2Test.
 *
 * @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
 */

public class A1Q2 {

    /**
     * Returns true if the given array has at least one run
     *
     * @param xs an array of numbers
     * @return true if the array has at least one run
     */

    public static boolean hasLengthTwoRun(double[] xs) {

	if (xs == null) {
	    return false;
	}
	
        boolean hasLengthTwoRun;
        hasLengthTwoRun = false;

        for (int i=1; i<xs.length && !hasLengthTwoRun; i++) {
            if (xs[i-1] == xs[i]) {
                hasLengthTwoRun = true;
            }
        }

        return hasLengthTwoRun;
    }

}
