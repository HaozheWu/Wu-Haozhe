/**
 * A run is a sequence of consecutive repeated values. In Java,
 * implement two class methods, both called getLongestRun, taking as
 * input the reference of an array and returning the length of the
 * longest run. The ﬁrst method takes as input the reference of an
 * array of numbers (all of type double), whereas the second method
 * takes as input the reference of an array of strings (objects of the
 * class String). Store these two methods in a class called A1Q3. You
 * can test your code using the program A1Q3Test.
 *
 * @author Marcel Turcotte (marcel.turcotte@uottawa.ca)
 */

public class A1Q3 {

    /**
     * Returns the length of the longest run.
     *
     * @param xs an array of numbers (primitive type)
     * @return the length of the longest run
     */

    public static int getLongestRun(double[] xs) {

	if (xs == null) {
	    return 0;
	}
	
	int max;
	max = 0;

	if (xs.length > 0) {
	    
	    int count;
	    max = count = 1;
	
	    for (int i=1; i<xs.length; i++) {
		if (xs[i-1] == xs[i]) {
		    count = count + 1;
		    if (count > max) {
			max = count;
		    }
		} else {
		    count = 1;
		}
	    }

	}

	return max;
    }

    /**
     * Returns the length of the longest run.
     *
     * @param xs an array of String objects (reference type)
     * @return the length of the longest run
     */

    public static int getLongestRun(String[] xs) {

        // pre-condition: none of the entries of the array are null
        
	if (xs == null) {
	    return 0;
	}
	
	int max;
	max = 0;

	if (xs.length > 0) {
	    
	    int count;
	    max = count = 1;
	
	    for (int i=1; i<xs.length; i++) {
		if (xs[i-1].equals(xs[i])) {
		    count = count + 1;
		    if (count > max) {
			max = count;
		    }
		} else {
		    count = 1;
		}
	    }

	}

	return max;
    }
}
